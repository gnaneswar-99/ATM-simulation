
import java.util.Scanner;

public class SimpleATM {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String storedUsername = "";
        int storedPin = 0;
        double balance = 0;
        boolean isAuthenticated = false;

        System.out.println("=== Create Account ===");
        System.out.print("Enter username: ");
        storedUsername = input.nextLine();
        System.out.print("Set a 4-digit PIN: ");
        storedPin = input.nextInt();
        input.nextLine();

        balance = 1000.00;
        System.out.println("Account created successfully! ₹1000 added as starting balance.");

        while (!isAuthenticated) {
            System.out.println("\n=== Login ===");
            System.out.print("Enter username: ");
            String enteredUsername = input.nextLine();
            System.out.print("Enter PIN: ");
            int enteredPin = input.nextInt();
            input.nextLine();

            if (enteredUsername.equals(storedUsername) && enteredPin == storedPin) {
                System.out.println("Login successful! Welcome.");
                isAuthenticated = true;
            } else {
                System.out.println("Incorrect username or PIN. Please try again.");
            }
        }

        boolean running = true;
        while (running) {
            System.out.println("\n=== ATM Menu ===");
            System.out.println("1) Check Balance");
            System.out.println("2) Deposit Money");
            System.out.println("3) Withdraw Money");
            System.out.println("4) Exit");
            System.out.print("Select an option: ");
            char select = input.next().charAt(0);

            switch (select) {
                case '1':
                    System.out.println("Your current balance is: " + balance);
                    break;

                case '2':
                    System.out.print("Enter the amount to deposit: ");
                    double deposit = input.nextDouble();
                    input.nextLine();
                    if (deposit < 0) {
                        System.out.println("Negative value cannot be deposited.");
                    } else {
                        balance += deposit;
                        System.out.println("Deposit successful! Current balance: " + balance);
                    }
                    break;

                case '3':
                    System.out.print("Enter the amount to withdraw: ");
                    int withdraw = input.nextInt();
                    input.nextLine();
                    if (withdraw > balance) {
                        System.out.println("Insufficient balance. Please check your balance.");
                    } else if (withdraw < 0) {
                        System.out.println("Invalid amount. Please try again.");
                    } else {
                        balance -= withdraw;
                        System.out.println("Withdrawal successful! Remaining balance: " + balance);
                    }
                    break;

                case '4':
                    System.out.println("Thank you for using our ATM service. Goodbye!");
                    running = false;
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
        input.close();
    }
}
