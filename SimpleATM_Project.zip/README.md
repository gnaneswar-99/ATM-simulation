
# SimpleATM - Bank Management System

This project is a simple ATM simulation written in Java, which includes basic functionalities like account creation, login, checking balance, depositing, and withdrawing money.

## Features
- Create an account with a username and a 4-digit PIN.
- Login using the registered credentials.
- Perform the following operations:
  - Check account balance.
  - Deposit money.
  - Withdraw money.
  - Exit the system.

## How to Run
1. Ensure you have Java installed on your system.
2. Compile the program:
   ```
   javac SimpleATM.java
   ```
3. Run the program:
   ```
   java SimpleATM
   ```

## Sample Output
```
=== Create Account ===
Enter username: JohnDoe
Set a 4-digit PIN: 1234
Account created successfully! ₹1000 added as starting balance.

=== Login ===
Enter username: JohnDoe
Enter PIN: 1234
Login successful! Welcome.

=== ATM Menu ===
1) Check Balance
2) Deposit Money
3) Withdraw Money
4) Exit
Select an option: 1
Your current balance is: 1000.0

Select an option: 2
Enter the amount to deposit: 500
Deposit successful! Current balance: 1500.0

Select an option: 4
Thank you for using our ATM service. Goodbye!
```

## Purpose
This project demonstrates the use of Java concepts such as:
- Input handling with `Scanner`
- Loops and conditionals for decision-making
- Basic arithmetic operations
